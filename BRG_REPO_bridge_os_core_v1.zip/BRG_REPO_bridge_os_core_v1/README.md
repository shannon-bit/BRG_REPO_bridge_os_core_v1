# BRG_REPO_bridge_os_core_v1

Canonical repository for the Bridge OS Universe core assets and the Revenue Engine v1.

## Contents

- `docs/` – OS Universe overview, revenue funnel spec, runtime behavior.
- `runtime/` – Bridge LLM + Perplexity + Emergent runtime specifications.
- `web/` – Example revenue funnel landing page for `probridge.space`.
- `sheets/` – Canonical Excel registries for the OS Universe and Revenue Funnel.

This repo is designed to be:
- Readable by Perplexity (via GitHub connector) as a Canon OS.
- Readable by GPT-based orchestrators as a Bridge OS Universe.
- The single source of truth for core entities (Gems, Bots, SOPs, Tasks, Flows, Repos).
